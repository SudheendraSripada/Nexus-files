"use client"

import { Calendar, BarChart3, Sparkles, Link2, Shield, Zap } from "lucide-react"

const features = [
  {
    icon: Calendar,
    title: "Smart Scheduling",
    description: "AI analyzes your audience to find the perfect posting times. Set it once, reach millions.",
    accent: "cyan" as const,
  },
  {
    icon: BarChart3,
    title: "Deep Analytics",
    description: "Real-time insights across all platforms. Understand what resonates with your audience.",
    accent: "magenta" as const,
  },
  {
    icon: Sparkles,
    title: "AI Content Studio",
    description: "Generate captions, hashtags, and even visuals. Your personal creative assistant.",
    accent: "amber" as const,
  },
  {
    icon: Link2,
    title: "Unified Inbox",
    description: "All messages, comments, and mentions in one place. Never miss an engagement.",
    accent: "cyan" as const,
  },
  {
    icon: Shield,
    title: "Team Collaboration",
    description: "Role-based access, approval workflows, and audit logs. Built for teams.",
    accent: "magenta" as const,
  },
  {
    icon: Zap,
    title: "Instant Publishing",
    description: "One click to publish everywhere. Cross-post to 10+ platforms simultaneously.",
    accent: "amber" as const,
  },
]

const accentColors = {
  cyan: {
    icon: "text-cyan",
    glow: "group-hover:shadow-[0_0_30px_rgba(0,245,255,0.2)]",
    border: "group-hover:border-cyan/30",
  },
  magenta: {
    icon: "text-magenta",
    glow: "group-hover:shadow-[0_0_30px_rgba(255,42,109,0.2)]",
    border: "group-hover:border-magenta/30",
  },
  amber: {
    icon: "text-amber",
    glow: "group-hover:shadow-[0_0_30px_rgba(255,184,48,0.2)]",
    border: "group-hover:border-amber/30",
  },
}

export function Features() {
  return (
    <section id="features" className="relative py-24 px-4">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyan/5 rounded-full blur-[200px]" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="font-mono text-xs uppercase tracking-[3px] text-cyan mb-4 block">
            Features
          </span>
          <h2 className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-gradient-cyan mb-6">
            Everything You Need
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl mx-auto">
            Powerful tools designed for creators, marketers, and agencies who demand more.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const colors = accentColors[feature.accent]
            return (
              <div
                key={index}
                className={`group glass rounded-2xl p-6 transition-all duration-300 ${colors.glow} ${colors.border}`}
              >
                {/* Icon */}
                <div className={`w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4 ${colors.icon}`}>
                  <feature.icon className="w-6 h-6" />
                </div>

                {/* Content */}
                <h3 className="font-mono font-bold text-lg mb-2 text-foreground">
                  {feature.title}
                </h3>
                <p className="font-sans text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
