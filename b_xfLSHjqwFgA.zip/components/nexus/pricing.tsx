"use client"

import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"

const plans = [
  {
    name: "Starter",
    price: "Free",
    period: "forever",
    description: "Perfect for individuals getting started.",
    features: [
      "3 social accounts",
      "30 scheduled posts/month",
      "Basic analytics",
      "Mobile app access",
    ],
    cta: "Get Started",
    featured: false,
  },
  {
    name: "Pro",
    price: "$29",
    period: "/month",
    description: "For creators who want to grow faster.",
    features: [
      "10 social accounts",
      "Unlimited scheduled posts",
      "Advanced analytics",
      "AI content suggestions",
      "Team collaboration (3 seats)",
      "Priority support",
    ],
    cta: "Start Free Trial",
    featured: true,
  },
  {
    name: "Agency",
    price: "$99",
    period: "/month",
    description: "For teams managing multiple brands.",
    features: [
      "Unlimited social accounts",
      "Unlimited scheduled posts",
      "White-label reports",
      "AI content generation",
      "Unlimited team seats",
      "Dedicated account manager",
      "API access",
    ],
    cta: "Contact Sales",
    featured: false,
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="relative py-24 px-4">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute bottom-0 left-1/4 w-[600px] h-[600px] bg-magenta/5 rounded-full blur-[200px]" />
        <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-amber/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="font-mono text-xs uppercase tracking-[3px] text-amber mb-4 block">
            Pricing
          </span>
          <h2 className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-gradient-cyan mb-6">
            Choose Your Plan
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl mx-auto">
            Start free, scale as you grow. No hidden fees, cancel anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-6 items-start">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl p-8 transition-all duration-300 ${
                plan.featured 
                  ? "glass border-glow lg:scale-105 lg:-my-4" 
                  : "glass glass-hover"
              }`}
            >
              {/* Featured Badge */}
              {plan.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="font-mono text-xs uppercase tracking-[2px] bg-cyan text-obsidian px-4 py-1 rounded-full">
                    Most Popular
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="mb-6">
                <h3 className="font-mono font-bold text-xl mb-2 text-foreground">
                  {plan.name}
                </h3>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="font-mono font-bold text-4xl text-gradient-cyan">
                    {plan.price}
                  </span>
                  <span className="font-sans text-muted-foreground">
                    {plan.period}
                  </span>
                </div>
                <p className="font-sans text-sm text-muted-foreground">
                  {plan.description}
                </p>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-cyan/10 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-cyan" />
                    </div>
                    <span className="font-sans text-sm text-muted-foreground">
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Button 
                className={`w-full btn-tech py-6 ${
                  plan.featured 
                    ? "bg-cyan text-obsidian hover:bg-cyan/90 glow-cyan" 
                    : "bg-white/5 hover:bg-white/10 text-foreground"
                }`}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
