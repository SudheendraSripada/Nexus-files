"use client"

const steps = [
  {
    number: "01",
    title: "Connect Platforms",
    description: "Link your social accounts in seconds. We support Instagram, Twitter, LinkedIn, TikTok, YouTube, and more.",
  },
  {
    number: "02",
    title: "Create & Schedule",
    description: "Use our AI-powered editor to craft content. Schedule for optimal times or let NEXUS decide.",
  },
  {
    number: "03",
    title: "Analyze & Grow",
    description: "Track performance across all channels. Get actionable insights to continuously improve.",
  },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="relative py-24 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="font-mono text-xs uppercase tracking-[3px] text-magenta mb-4 block">
            How It Works
          </span>
          <h2 className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-gradient-cyan mb-6">
            Simple Yet Powerful
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl mx-auto">
            Get up and running in minutes, not hours. No complex setup required.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent -translate-y-1/2" />
          
          <div className="grid lg:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div 
                key={index}
                className="relative group"
              >
                {/* Card */}
                <div className="glass glass-hover rounded-2xl p-8 h-full">
                  {/* Step Number */}
                  <div className="relative mb-6">
                    <span className="font-mono font-bold text-6xl text-gradient-cyan opacity-20">
                      {step.number}
                    </span>
                    <div className="absolute top-1/2 left-16 -translate-y-1/2 w-12 h-px bg-gradient-to-r from-cyan to-transparent" />
                  </div>

                  {/* Content */}
                  <h3 className="font-mono font-bold text-xl mb-3 text-foreground">
                    {step.title}
                  </h3>
                  <p className="font-sans text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Connector dot */}
                <div className="hidden lg:flex absolute -bottom-4 left-1/2 -translate-x-1/2 w-8 h-8 items-center justify-center">
                  <div className="w-3 h-3 rounded-full bg-cyan/50 group-hover:bg-cyan transition-colors" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
