"use client"

import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function CTA() {
  return (
    <section className="relative py-24 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="relative glass rounded-3xl p-12 md:p-16 text-center overflow-hidden border-glow">
          {/* Background Effects */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-24 -left-24 w-48 h-48 bg-cyan/20 rounded-full blur-[100px]" />
            <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-magenta/20 rounded-full blur-[100px]" />
          </div>

          {/* Content */}
          <div className="relative z-10">
            <h2 className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-gradient-cyan mb-6">
              Ready to Transform Your Social Strategy?
            </h2>
            <p className="font-sans text-lg text-muted-foreground max-w-xl mx-auto mb-8">
              Join thousands of creators and agencies who&apos;ve already made the switch. 
              Start your free trial today.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button 
                size="lg"
                className="btn-tech bg-cyan text-obsidian hover:bg-cyan/90 glow-cyan px-8 py-6 text-base"
              >
                Start Free Trial
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <span className="font-mono text-xs text-muted-foreground">
                No credit card required
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
