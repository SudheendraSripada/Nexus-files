"use client"

import { ArrowRight, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 px-4 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient orbs */}
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-cyan/10 rounded-full blur-[128px]" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-magenta/10 rounded-full blur-[128px]" />
        
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '64px 64px'
          }}
        />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 glass glass-hover rounded-full mb-8">
          <Zap className="w-4 h-4 text-amber" />
          <span className="font-mono text-xs uppercase tracking-[2px] text-muted-foreground">
            Now with AI-Powered Scheduling
          </span>
        </div>

        {/* Main Headline */}
        <h1 className="font-mono font-bold text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-tight mb-6">
          <span className="text-gradient-cyan">Automate</span>
          <br />
          <span className="text-foreground">Your Social</span>
          <br />
          <span className="text-foreground">Presence</span>
        </h1>

        {/* Subheadline */}
        <p className="font-sans text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
          NEXUS connects all your social platforms into one seamless workflow. 
          Schedule, analyze, and amplify—while you focus on what matters.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button 
            size="lg"
            className="btn-tech bg-cyan text-obsidian hover:bg-cyan/90 glow-cyan px-8 py-6 text-base"
          >
            Start Free Trial
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <Button 
            variant="outline"
            size="lg"
            className="btn-tech border-border hover:border-cyan/50 hover:bg-white/5 px-8 py-6 text-base"
          >
            Watch Demo
          </Button>
        </div>

        {/* Social Proof */}
        <div className="mt-16 pt-8 border-t border-border/50">
          <p className="font-mono text-xs uppercase tracking-[2px] text-muted-foreground mb-6">
            Trusted by 10,000+ creators & agencies
          </p>
          <div className="flex items-center justify-center gap-8 opacity-40">
            {["TechCrunch", "Forbes", "Wired", "ProductHunt"].map((brand) => (
              <span 
                key={brand}
                className="font-mono text-sm tracking-wider text-muted-foreground"
              >
                {brand}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
