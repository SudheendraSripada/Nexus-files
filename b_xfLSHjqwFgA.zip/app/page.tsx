import { Header } from "@/components/nexus/header"
import { Hero } from "@/components/nexus/hero"
import { Features } from "@/components/nexus/features"
import { HowItWorks } from "@/components/nexus/how-it-works"
import { Pricing } from "@/components/nexus/pricing"
import { CTA } from "@/components/nexus/cta"
import { Footer } from "@/components/nexus/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Features />
      <HowItWorks />
      <Pricing />
      <CTA />
      <Footer />
    </main>
  )
}
